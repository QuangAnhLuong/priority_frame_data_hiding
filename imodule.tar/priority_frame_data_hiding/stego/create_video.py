import cv2
import numpy as np

OUTPUT = "input_video.mp4"

WIDTH = 640
HEIGHT = 360
FPS = 10
DURATION = 8

fourcc = cv2.VideoWriter_fourcc(*"mp4v")

out = cv2.VideoWriter(
    OUTPUT,
    fourcc,
    FPS,
    (WIDTH, HEIGHT)
)

total = FPS * DURATION

for i in range(total):

    frame = np.zeros(
        (HEIGHT, WIDTH, 3),
        dtype=np.uint8
    )

    if i < 20:
        frame[:] = (30,30,180)

    elif i < 40:
        frame[:] = (30,180,30)

    elif i < 60:
        frame[:] = (180,30,30)

    else:
        frame[:] = (180,180,30)

    cv2.putText(
        frame,
        f"FRAME {i:04d}",
        (150,180),
        cv2.FONT_HERSHEY_SIMPLEX,
        1.2,
        (255,255,255),
        3
    )

    out.write(frame)

out.release()

print("[+] Video created")
