import cv2
import os

FRAME_DIR = "stego_frames"

OUTPUT = "stego_video.mp4"

files = sorted(os.listdir(FRAME_DIR))

first = cv2.imread(
    os.path.join(FRAME_DIR, files[0])
)

height, width = first.shape[:2]

fourcc = cv2.VideoWriter_fourcc(*"mp4v")

out = cv2.VideoWriter(
    OUTPUT,
    fourcc,
    10,
    (width, height),
    False
)

for file in files:

    frame = cv2.imread(
        os.path.join(FRAME_DIR, file),
        cv2.IMREAD_GRAYSCALE
    )

    out.write(frame)

out.release()

print("[+] Stego video created")
