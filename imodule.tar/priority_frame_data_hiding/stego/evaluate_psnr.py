from PIL import Image
import numpy as np
import os
from skimage.metrics import peak_signal_noise_ratio

FRAME_DIR = "frames"

STEGO_DIR = "stego_frames"

OUTPUT = "results/psnr.txt"

psnrs = []

files = sorted(os.listdir(STEGO_DIR))

for file in files:

    orig = np.array(
        Image.open(
            os.path.join(FRAME_DIR, file)
        ).convert("L")
    )

    stego = np.array(
        Image.open(
            os.path.join(STEGO_DIR, file)
        ).convert("L")
    )

    psnr = peak_signal_noise_ratio(
        orig,
        stego
    )

    psnrs.append(psnr)

avg = np.mean(psnrs)

with open(OUTPUT, "w") as f:

    f.write(
        f"Average PSNR: {avg:.2f} dB\n"
    )

print(f"[+] Average PSNR = {avg:.2f}")
