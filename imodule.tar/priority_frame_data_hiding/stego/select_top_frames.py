INPUT = "results/ranked_frames.txt"

OUTPUT = "results/selected_frames.txt"

TOP_N = 3

selected = []

with open(INPUT, "r") as f:

    lines = f.readlines()

    for line in lines[:TOP_N]:

        frame, diff = line.split()

        selected.append(frame)

with open(OUTPUT, "w") as out:

    out.write("Selected:\n")

    for frame in selected:

        out.write(frame + "\n")

        print(frame)
