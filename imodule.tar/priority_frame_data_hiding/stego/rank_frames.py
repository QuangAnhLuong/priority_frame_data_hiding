INPUT = "results/histogram_diff.txt"

OUTPUT = "results/ranked_frames.txt"

frames = []

with open(INPUT, "r") as f:

    for line in f:

        frame, diff = line.split()

        frames.append(
            (frame, float(diff))
        )

frames.sort(
    key=lambda x: x[1],
    reverse=True
)

with open(OUTPUT, "w") as out:

    for frame, diff in frames:

        line = f"{frame} {diff:.4f}"

        print(line)

        out.write(line + "\n")
