import cv2
import os

VIDEO = "input_video.mp4"

OUTPUT = "frames"

os.makedirs(OUTPUT, exist_ok=True)

video = cv2.VideoCapture(VIDEO)

count = 0

while True:

    ret, frame = video.read()

    if not ret:
        break

    out_name = f"{OUTPUT}/frame_{count:04d}.png"

    cv2.imwrite(out_name, frame)

    print(f"[+] Saved {out_name}")

    count += 1

video.release()
