from PIL import Image
import numpy as np
import os

SELECTED = "results/selected_frames.txt"

SECRET = "secret.txt"

OUTPUT_DIR = "stego_frames"

os.makedirs(OUTPUT_DIR, exist_ok=True)

with open(SECRET, "r") as f:
    secret = f.read().strip()

bits = ''.join(
    format(ord(c),'08b')
    for c in secret
)

frames = []

with open(SELECTED, "r") as f:

    for line in f:

        if "Selected" in line:
            continue

        frames.append(line.strip())

bit_idx = 0

for frame_name in frames:

    path = os.path.join(
        "frames",
        frame_name
    )

    img = np.array(
        Image.open(path).convert("L")
    )

    flat = img.flatten()

    for i in range(len(flat)):

        if bit_idx >= len(bits):
            break

        flat[i] = (
            flat[i] & 254
        ) | int(bits[bit_idx])

        bit_idx += 1

    stego = flat.reshape(img.shape)

    out_path = os.path.join(
        OUTPUT_DIR,
        frame_name
    )

    Image.fromarray(
        stego.astype(np.uint8)
    ).save(out_path)

print("[+] Secret embedded")
