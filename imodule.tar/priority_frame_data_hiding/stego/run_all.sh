#!/bin/bash

echo "[1] Create video"
python3 create_video.py

echo "[2] Extract frames"
python3 extract_frames.py

echo "[3] Histogram difference"
python3 histogram_diff.py

echo "[4] Rank frames"
python3 rank_frames.py

echo "[5] Select top frames"
python3 select_top_frames.py

echo "[6] Embed secret"
python3 embed_priority.py

echo "[7] Rebuild video"
python3 rebuild_video.py

echo "[8] Evaluate PSNR"
python3 evaluate_psnr.py

echo "[9] Extract secret"
python3 extract_secret.py

echo "[+] Done"
