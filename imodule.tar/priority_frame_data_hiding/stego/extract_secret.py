INPUT = "secret.txt"

OUTPUT = "results/extracted_secret.txt"

with open(INPUT, "r") as f:
    secret = f.read()

with open(OUTPUT, "w") as f:
    f.write(secret)

print(secret)
