import cv2
import os
import numpy as np

FRAME_DIR = "frames"

OUTPUT = "results/histogram_diff.txt"

os.makedirs("results", exist_ok=True)

files = sorted(os.listdir(FRAME_DIR))

with open(OUTPUT, "w") as out:

    for i in range(1, len(files)):

        prev = cv2.imread(
            os.path.join(FRAME_DIR, files[i-1]),
            cv2.IMREAD_GRAYSCALE
        )

        curr = cv2.imread(
            os.path.join(FRAME_DIR, files[i]),
            cv2.IMREAD_GRAYSCALE
        )

        hist1 = cv2.calcHist(
            [prev],
            [0],
            None,
            [256],
            [0,256]
        )

        hist2 = cv2.calcHist(
            [curr],
            [0],
            None,
            [256],
            [0,256]
        )

        diff = np.sum(np.abs(hist1 - hist2))

        line = f"{files[i]} {diff:.4f}"

        print(line)

        out.write(line + "\n")
